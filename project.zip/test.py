import customtkinter as ctk
from websockets.asyncio.client import connect
import threading
import websockets
import asyncio
import json


# Appearance
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

#------------------------------------WEBSOCKETS---------------------------------------------


#SERVER_URI = "ws://plastic-franky-badpeople-f1c7808a.koyeb.app/"
SERVER_URI = "ws://103.250.153.157:8080"

username = "Shashwat"
regnum = 1221
target = "user2"

async def send_messages(client_connection):
    while True:
        message = await message_queue.get()

        current_target = target
	
        if message == "exit":
            await client_connection.close()

        if message:
            packet = json.dumps(
                    {
                        "user": username,
                        "target": current_target,
                        "msg": message
                    }
                )
            await client_connection.send(packet)

async def receive_messages(client_connection):
    while True:
        data = await client_connection.recv()
        print(data)
        try: 
            msg = json.loads(data)
        except:
            msg = {"from": "Server", "msg": data}
        await incoming_queue.put(msg)

async def main():
    async for client_connection in connect(SERVER_URI):
        try:
            regdata = json.dumps(
                    {
                    "user": username,
                    "regnumber": regnum
                }
            )

            await client_connection.send(regdata)
            send_task = asyncio.create_task(send_messages(client_connection))
            recv_task = asyncio.create_task(receive_messages(client_connection))
            await asyncio.gather(send_task, recv_task)

        except websockets.exceptions.ConnectionClosed:
            print("Server Closed connection")
            exit()

message_queue = asyncio.Queue()
incoming_queue = asyncio.Queue()
loop = asyncio.new_event_loop()


#------------------------------------USER INTERFACE---------------------------------------


# Main window
app = ctk.CTk()
app.title("Simple Chat App")
app.geometry("600x400")

# Configure grid for responsiveness
app.grid_rowconfigure(0, weight=1)
app.grid_columnconfigure(1, weight=1)

# --- Left frame: user list ---
user_frame = ctk.CTkFrame(app, width=150)
user_frame.grid(row=0, column=0, sticky="ns")
user_frame.grid_rowconfigure(0, weight=1)

# Users
users = ["user2", "Guest1", "Guest2", "Guest3"]

# Listbox to show users
user_listbox = ctk.CTkScrollableFrame(user_frame)
user_listbox.pack(fill="both", expand=True, padx=5, pady=5)

for u in users:
    btn = ctk.CTkButton(user_listbox, text=u, command=lambda name=u: open_chat(name))
    btn.pack(fill="x", pady=2)

# --- Right frame: chat area ---
chat_frame = ctk.CTkFrame(app)
chat_frame.grid(row=0, column=1, sticky="nsew")
chat_frame.grid_rowconfigure(0, weight=1)
chat_frame.grid_columnconfigure(0, weight=1)

# Chat headeri
chat_header = ctk.CTkLabel(chat_frame, text="Select a user to start chat", font=ctk.CTkFont(size=16, weight="bold"))
chat_header.grid(row=0, column=0, sticky="n", padx=1, pady=1, columnspan=2)

# Chat messages display
chat_display = ctk.CTkTextbox(chat_frame, state="disabled")
chat_display.grid(row=0, column=0, sticky="nsew", padx=1, pady=(30,0), rowspan=2, columnspan=2)

# Message entry
message_entry = ctk.CTkEntry(chat_frame)
message_entry.grid(row=2, column=0, sticky="ew", padx=10, pady=5)



# Send button
def send_message(event = None):
    msg = message_entry.get()
    if msg:
        asyncio.run_coroutine_threadsafe(message_queue.put(msg), loop)
        chat_display.configure(state="normal")
        chat_display.insert("end", f"You: {msg}\n")
        chat_display.configure(state="disabled")
        message_entry.delete(0, "end")

send_btn = ctk.CTkButton(chat_frame, text="Send", command=send_message)
send_btn.grid(row=2, column=1, sticky="e", padx=10, pady=5)
message_entry.bind("<Return>",send_message)

def check_incoming():
    try:
        while True:
            data = incoming_queue.get_nowait()  # get message if available
            sender = data['from']
            msg = data["msg"]

            chat_display.configure(state="normal")
            chat_display.insert("end", f"{sender}: {msg}\n")
            chat_display.configure(state="disabled")
    except asyncio.QueueEmpty:
        pass
    app.after(100, check_incoming)  # check again in 100ms

# Start polling
app.after(100, check_incoming)

# Function to open chat with a user
def open_chat(user):
    global target
    target = user
    chat_header.configure(text=f"Chat with {user}")
    chat_display.configure(state="normal")
    chat_display.delete("1.0", "end")
    chat_display.insert("end", f"Starting chat with {user}...\n")
    chat_display.configure(state="disabled")

def start_loop():
    asyncio.set_event_loop(loop)
    loop.run_until_complete(main())

threading.Thread(target=start_loop, daemon=True).start()
app.mainloop()

