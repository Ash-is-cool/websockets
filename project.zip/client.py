import asyncio
import json
import websockets
import aioconsole
from websockets.asyncio.client import connect

username = "shashwat"
regnum = 1221
target = "user2"

async def send_messages(client_connection):
    while True:
                message = await aioconsole.ainput()

                if message == "exit":
                    await client_connection.close()

                if message:
                    packet = json.dumps(
                            {
                            "user": username,
                            "target": target,
                            "msg": message
                        }
                    )
                    await client_connection.send(packet)

async def receive_messages(client_connection):
    while True:
        print(await client_connection.recv())

async def main():
    async for client_connection in connect("ws://localhost:8765"):
        try:
            regdata = json.dumps(
                    {
                    "user": username,
                    "regnumber": regnum
                }
            )

            await client_connection.send(regdata)
            message = await client_connection.recv()
            send_task = asyncio.create_task(send_messages(client_connection))
            recv_task = asyncio.create_task(receive_messages(client_connection))
            await asyncio.gather(send_task, recv_task)

        except websockets.exceptions.ConnectionClosed:
            print("Server Closed connection")
            exit()


if __name__ == "__main__":
    asyncio.run(main())
