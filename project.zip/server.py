import asyncio
import json
import aioconsole
from websockets.asyncio.server import serve, broadcast

users = {}

async def handler(server_connection):
    reguser = "unknown"
    try:
        Resgistration = await server_connection.recv()
        Resgistration = json.loads(Resgistration)
        print(f"Resgistration recieved: {Resgistration}")

        reguser = Resgistration["user"]
        regnum = Resgistration["regnumber"]

        if regnum in [1221, 414214, 41225]:
            pass
        else:
            server_connection.close(reason="invalid resgistration")

        users.update({reguser:server_connection})

        print(server.connections)
        broadcast(server.connections, f"{reguser} Online")

        async for message in server_connection:
            data = json.loads(message)

            user = data["user"]
            target = data["target"]
            msg = data["msg"]

            print(msg)

            if target not in users:
                await server_connection.send(f"{target} Offline")

            else:
                data = json.dumps({
                    "from": user,
                    "msg": msg
                })
                await users[target].send(data)

    except Exception as e:
        print(f"Error for {reguser}: {e}")

    finally:
        # --- Cleanup always happens ---
        if reguser in users:
            broadcast(server.connections,f"{reguser} Offline")
            print(f"Removing user: {reguser}")
            del users[reguser]
        await server_connection.close()
        print("Connection closed")

async def main():
    global server
    async with serve(handler, "localhost", 8765, ping_interval=None, ping_timeout= None) as server:
        await server.start_serving()
        if await aioconsole.ainput() == "exit":
            server.close()


if __name__ == "__main__":
    asyncio.run(main())
